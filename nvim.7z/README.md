### 必须安装的一些东西

> ## python3的pip
> > 
> > ```
> > pacman -S python-pip
> > ```
> --------

> ## ncm2
> > ```
> > python3 -m pip install pynvim
> > ```
> --------


> ## ncm2-jedi
> > 
> > ```
> > sudo pip install jedi
> > ```
> --------

> ## ncm2-pyclang
> > ```
> > pacman -S clang
> > ```
> --------
